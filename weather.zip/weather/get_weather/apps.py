from django.apps import AppConfig


class GetWeatherConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'get_weather'

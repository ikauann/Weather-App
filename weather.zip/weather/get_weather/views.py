from django.http import HttpResponse
from django.shortcuts import render
from django.template import loader

import requests
from bs4 import BeautifulSoup

def index(request):
     if request.method == "POST":
          try:
               search = request.POST.get('search')
               url = f"https://www.google.com/search?q=weather+{search}"
               headers = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:77.0) Gecko/20100101 Firefox/77.0'}
               page = requests.get(url, headers=headers)
               soup = BeautifulSoup(page.text, 'html')

               title = soup.findAll('div', {'class':'wob_loc q8U8x'})[0].getText()

               c = soup.findAll('span', {'class':'wob_t q8U8x'})[0].getText()
               c = (str(c) + '°C')

               img = soup.findAll('img', {'class':'wob_tci'})[0]

               detalhes = img['alt']
               imagem = img['src']

               status = soup.findAll('div', {'class':'wtsRwe'})[0]
               vento = status.findAll('span', {'class':'wob_t'})[0].getText()
               humidade = status.findAll('span', {'id':'wob_hm'})[0].getText()

               print(search)


               return render(request, 'index.html', {'titles':title,
                                                  'img':imagem,
                                                  'detalhes':detalhes,
                                                  'graus': c,
                                                  'vento': vento,
                                                  'humidade': humidade})
          except IndexError:
               return render(request, 'index_error.html')
     return render(request, 'index_error.html')